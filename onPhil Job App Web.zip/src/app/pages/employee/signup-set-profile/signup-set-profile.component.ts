import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-set-profile',
  templateUrl: './signup-set-profile.component.html',
  styleUrls: ['./signup-set-profile.component.scss']
})
export class SignupSetProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
