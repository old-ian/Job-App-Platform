import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-preference',
  templateUrl: './job-preference.component.html',
  styleUrls: ['./job-preference.component.scss']
})
export class JobPreferenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
