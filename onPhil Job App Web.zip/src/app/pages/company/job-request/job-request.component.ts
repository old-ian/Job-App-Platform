import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-request',
  templateUrl: './job-request.component.html',
  styleUrls: ['./job-request.component.scss']
})
export class JobRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
