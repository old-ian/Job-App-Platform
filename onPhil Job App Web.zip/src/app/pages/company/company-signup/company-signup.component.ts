import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-signup',
  templateUrl: './company-signup.component.html',
  styleUrls: ['./company-signup.component.scss']
})
export class CompanySignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
